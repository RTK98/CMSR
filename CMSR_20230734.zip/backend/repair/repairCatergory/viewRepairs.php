<?php include'../../header.php' ; ?>
<?php include'../../menu.php' ; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Products</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="addRepaircatergory.php" class="btn btn-sm btn-outline-secondary">Add New Repair</a>
            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar" class="align-text-bottom"></span>
                This week
            </button>
            <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>
        </div>
    </div>
    <h2>Products List</h2>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Qty.</th>
                    <th scope="col">Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td</td>
                        <td></td>
                        <td>
                            <form method='post' action="edit.php">
                                <input type="hidden" name="ProductId">
                                <button type="submit" name="action" value="edit">Edit</button>
                            </form>

                        </td>
                </tr>
            </tbody>
        </table>
    </div>
</main>
<?php include'../../footer.php' ; ?>