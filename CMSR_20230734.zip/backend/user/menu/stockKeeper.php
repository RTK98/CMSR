<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3 sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="<?= SYSTEM_PATH ?>index.php">
                    <span data-feather="home" class="align-text-bottom"></span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>tasks/viewTasks.php">
                    <span data-feather="file" class="align-text-bottom"></span>
                    Products Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>products/view.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Categories Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>products/stock/viewStock.php">
                    <span data-feather="file" class="align-text-bottom"></span>
                    Stock Management
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>order/requesting/viewReqItems.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Requested Items
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>order/requesting/viewRelItems.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Release Items
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>order/requesting/viewRelItems.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Return Items
                </a>
            </li>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>order/requesting/viewRelItems.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Expired Items
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>order/requesting/viewRelItems.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Damage Items
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= SYSTEM_PATH ?>jobCard/viewJobCard.php">
                    <span data-feather="shopping-cart" class="align-text-bottom"></span>
                    Reports
                </a>
            </li>
        </ul>

    </div>
</nav>