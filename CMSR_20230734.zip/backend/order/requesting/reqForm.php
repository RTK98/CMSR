<?php
include'../../header.php';
include'../../menu.php';
include'rand.php';
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Add Order</h1>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="col-md-12">
                        <?php
                        extract($_POST);
                        if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'edit' || $_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'addProduct' || $_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'removeProduct' || $_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'addOrder') {
                            $JobCardsInspetionId;
                            $jobCardsRepairId;
                            $db = dbconn();
                            $sql = "SELECT ins.InspectionId,ins.InspectionNo,ins.AddDate,ins.Millege,ins.inspectionNotes,"
                                    . "cv.vehicleId,cv.registerLetter,cv.RegistrationNo,vc.CatergoryName,u.FirstName,u.LastName,cus.CustomerID,cus.FirstName AS 'CustomerFirstName',cus.LastName AS 'CustomerLastName' FROM inspections ins "
                                    . "LEFT JOIN customervehicles cv ON ins.VehicleNo=cv.vehicleId "
                                    . "LEFT JOIN vehicle_catergories vc ON cv.VehicleType=vc.VCatergoryId "
                                    . "LEFT JOIN users u ON ins.AddUser=u.UserId "
                                    . "LEFT JOIN customer cus ON ins.CustomerName=cus.CustomerID WHERE InspectionId='$JobCardsInspetionId';";
                            $result = $db->query($sql);
                            $row = $result->fetch_assoc();
                            $JobCardsInspetionId = $row['InspectionId'];
                            $row['CustomerFirstName'];
                            $row['CustomerLastName'];
                            $row['CatergoryName'];
                            $row['Millege'];
                            $row['AddDate'];
                            $row['InspectionNo'];
                            $row['FirstName'];
                            $row['LastName'];
                            $customerId = $row['CustomerID'];
                            $VehicleId = $row['vehicleId'];

                            $sql1 = "SELECT jobCardsRepairId,JobCardNo FROM Job_cardsrepair WHERE jobCardsRepairId = '$jobCardsRepairId'";
                            $result1 = $db->query($sql1);
                            $row1 = $result1->fetch_assoc();
                            $jobCardsRepairId = $row1['jobCardsRepairId'];
                            $row1['JobCardNo'];
                        }
                        ?>
                        <?php
                        extract($_POST);
                        if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'addProduct') {
                            $JobCardsInspetionId;
                            $jobCardsRepairId;
                            $ProductName;
                            $QtyProduct;
                            $addeduser = $_SESSION['userId'];
                            $adddate = date("Y-m-d");
                            $db = dbConn();
                            $sqladdreqProduct = "INSERT INTO orderrequestitems(JobCardId, ReqProductId,AddUser, AddDate,Qty) VALUES ('$jobCardsRepairId','$ProductName','$addeduser','$adddate','$QtyProduct')";

                            $resultaddReqProduct = $db->query($sqladdreqProduct);
                        }
                        ?>
                        <?php
                        extract($_POST);
                        if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'removeProduct') {
                            $ProductId;
                            $db = dbConn();
                            $sqlDeleteItems = "DELETE FROM orderrequestitems WHERE orderReqItemId='$ProductId'";
                            $db->query($sqlDeleteItems);
                        }
                        ?>
                        <?php
                        extract($_POST);
                        if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'addOrder') {
//                        $productData = [];
//                        $repairData = [];
//                        print_r($productData);
//                        print_r($repairData);

                            $addeduser = $_SESSION['userId'];
                            $AddDate = date('Y-m-d');
                            $timestamp = strtotime($AddDate);
                            $currentdatenumber = date('Ymd', $timestamp);
                            $randomNumber;
                            $OrderNo = 'ODR' . $currentdatenumber . $randomNumber;

                            $db = dbConn();
                            echo $sqlorders = "INSERT INTO orders(orderNo, InspectionNo,JobCardNo, CustomerName,VehicleNo,AddDate,AddUser,Status) VALUES ('$OrderNo','$JobCardsInspetionId','$jobCardsRepairId','$customerId','$VehicleId','$AddDate','$addeduser','1')";
                            $resultsOrder = $db->query($sqlorders);
                            $OrderId= $db->insert_id;
//                            die();
                            $sqlAddproduct = "SELECT odr.orderReqItemId,odr.JobCardId, odr.Qty, jb.JobCardNo, p.ProductId ,p.ProductName FROM orderrequestitems odr "
                                    . "LEFT JOIN job_cardsrepair jb ON odr.JobCardId = jb.jobCardsRepairId "
                                    . "LEFT JOIN products p ON odr.ReqProductId = p.ProductId WHERE odr.JobCardId = '$jobCardsRepairId';";
                            $db = dbConn();
                            $resultAddproduct = $db->query($sqlAddproduct);
                            ?>
                            <?php
                            if ($resultAddproduct->num_rows > 0) {
                                while ($rowOderProduct = $resultAddproduct->fetch_assoc()) {
                                    ?>


                                    <?php
                                    echo $addedproductid = $rowOderProduct['ProductId'];
                                    echo $addedproductqty = $rowOderProduct['Qty'];

                                    echo $sqlestimateinsert = "INSERT INTO orderitems(OrderId, ProductId,Qty, AddUser,AddDate) VALUES ('$OrderId','$addedproductid','$addedproductqty','$addeduser','$AddDate')";
                                    $resultaEstimateInsert = $db->query($sqlestimateinsert);
                                    ?>
                                    <?php
                                }
                            }
                        }
                        ?>

                        <div class="card">
                            <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
                                <div class="card-body">
                                    <section class="m-1">
                                        <div class="card-header">
                                            <img width="60" src="<?= SYSTEM_PATH ?>/assets/img/logo.png" title="logo" alt="logo" 
                                                 styly=" 
                                                 display: block;
                                                 margin-left: auto;
                                                 margin-right: auto;
                                                 ">
                                            <h5 class='m-1'style="text-align: center; font-weight: bold;">Replica Speed Motor Garage</h5>
                                            <p class='m-1' style="text-align: center;">130A, Horahena Rd, Pannipitiya.</p>
                                            <p class='m-1' style="text-align: center;">0779 200 480</p>

                                        </div>
                                        <div class="card-body">
                                            <div>
                                                <h4 class='m-1'style="text-align: center; font-weight: bold;">Inspection Report</h4>
                                            </div>

                                            <div class="row">
                                                <div class="col">
                                                    <div>
                                                        <p> Customer Name : <?= $row['CustomerFirstName'] . ' ' . $row['CustomerLastName']; ?>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>Vehicle No : <?= $row['registerLetter'] . ' - ' . $row['RegistrationNo']; ?> </p>
                                                    </div>
                                                    <div>
                                                        <p>Vehicle Type : <?= $row['CatergoryName']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Millage : <?= $row['Millege']; ?></p>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div>
                                                        <p> INS Date :  <?= $row['AddDate']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p> INS NO. : <?= $row['InspectionNo']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Inspection Officer : <?= $row['FirstName'] . ' ' . $row['LastName']; ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <div class="container m-1">
                                        <table class="table m-1">
                                            <thead>
                                                <tr style="background-color: #d2d2d2">
                                                    <th scope="col">#</th>
                                                    <th scope="col">Item</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $db = dbconn();
                                                $sqlEngine = "SELECT * FROM `inspectioncustomerselected` JOIN inspectionitems ON inspectionitems.InspectionItemId = inspectioncustomerselected.InspectionItem_Id WHERE Inspecion_id = $JobCardsInspetionId;";
                                                $resultEngine = $db->query($sqlEngine);

                                                if ($resultEngine->num_rows > 0) {
                                                    $n = 1;
                                                    while ($rowengineItems = $resultEngine->fetch_assoc()) {
                                                        $inspectionItemId = $rowengineItems['InspectionItemId'];
                                                        $insItemName = $rowengineItems['InsItemName'];
                                                        // Display the radio buttons with dynamic names and pre-selected value
                                                        echo '<tr>';
                                                        echo '<td style="background-color: #d2d2d2">' . $n . '</td>';
                                                        echo '<td>' . $insItemName . '</td>';

                                                        echo '</tr>';

                                                        $n++;
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <div class="mb-3">
                                            <label for="ProductDescription" class="form-label">Special Notes</label>
                                            <textarea class="form-control" id="ProductDescription" rows="3" name="ProductDescription" readonly><?= $row['inspectionNotes']; ?></textarea>
                                            <div class="text-danger"><?= @$messages['error_Product_des']; ?></div>
                                        </div>
                                    </div>
                                                <!-- <div class="text-danger"><?= @$messages['error_Product_size']; ?></div> -->
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!--            Requesting Order-->

            <div class="col-md-5">
                <div class="card">
                    <div class="card-header">
                    </div>
                    <div class="col-md-12">
                        <div class="card">
                            <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
                                <div class="card-body">
                                    <section class="m-1">
                                        <div class="card-header">
                                            <img width="60" src="<?= SYSTEM_PATH ?>/assets/img/logo.png" title="logo" alt="logo" 
                                                 styly=" 
                                                 display: block;
                                                 margin-left: auto;
                                                 margin-right: auto;
                                                 ">
                                            <h5 class='m-1'style="text-align: center; font-weight: bold;">Replica Speed Motor Garage</h5>
                                            <p class='m-1' style="text-align: center;">130A, Horahena Rd, Pannipitiya.</p>
                                            <p class='m-1' style="text-align: center;">0779 200 480</p>
                                        </div>
                                        <div class="card-body">
                                            <h5 class='m-1'style="text-align: center; font-weight: bold;">Requesting Order</h5>
                                            <div class="row">
                                                <div class="col">
                                                    <div>
                                                        <p> Customer Name : <?= $row['CustomerFirstName'] . ' ' . $row['CustomerLastName']; ?>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>Vehicle No : <?= $row['registerLetter'] . ' - ' . $row['RegistrationNo']; ?> </p>
                                                    </div>
                                                    <div>
                                                        <p>Vehicle Type : <?= $row['CatergoryName']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Millage : <?= $row['Millege']; ?></p>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div>
                                                        <p> INS Date :  <?= $row['AddDate']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p> INS NO. :<?= $row['InspectionNo']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Inspection Officer :  <?= $row['FirstName'] . ' ' . $row['LastName']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Job Card No:  <?= $row1['JobCardNo'] ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <section>
                                        <div class="container m-1">
                                            <section>
                                                <h6>Products</h6>
                                                <table class="table m-1">
                                                    <thead>
                                                        <tr style="background-color: #d2d2d2">
                                                            <th scope="col">#</th>
                                                            <th scope="col">Description</th>
                                                            <th scope="col">Qty</th>
                                                            <th scope="col">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        echo $sqlshowproduct = "SELECT odr.orderReqItemId,odr.JobCardId, odr.Qty, jb.JobCardNo, p.ProductName FROM orderrequestitems odr "
                                                                . "LEFT JOIN job_cardsrepair jb ON odr.JobCardId = jb.jobCardsRepairId "
                                                                . "LEFT JOIN products p ON odr.ReqProductId = p.ProductId WHERE odr.JobCardId = '$jobCardsRepairId';";
                                                        $db = dbConn();
                                                        $resultshowproduct = $db->query($sqlshowproduct);
                                                        ?>
                                                        <?php
                                                        $totalProduct = 0;
                                                        if ($resultshowproduct->num_rows > 0) {
                                                            $i = 1;

                                                            while ($rowshowp = $resultshowproduct->fetch_assoc()) {
                                                                ?><tr>
                                                                    <td><?= $i ?></td>
                                                                    <td><?= $rowshowp['ProductName'] ?></td>
                                                                    <td><?= $rowshowp['Qty'] ?></td>
                                                                    <td> 
                                                                        <?php
                                                                        $ProductId = $rowshowp['orderReqItemId'];
                                                                        ?>
                                                                        <input type="text" name="ProductId" value="<?= $ProductId ?>" >
                                                                        <input type="text" name="JobCardsInspetionId" value="<?= $JobCardsInspetionId ?>" >
                                                                        <input type="text" name="jobCardsRepairId" value="<?= $jobCardsRepairId ?>" >
                                                                        <button type="submit" class="btn btn-danger btn-sm" name="action" value="removeProduct" onclick="return confirm('Are you sure you want to remove this item?')">Remove</button>


                                                                    </td>
                                                                </tr>
                                                                <?php
                                                                $i++;
                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </section>
                                        </div>
                                        <div class="card-footer">
                                            <input type="hidden" name="InspectionId" value="<?= $JobCardsInspetionId ?>" >
                                            <button type="submit" name="action" value="addOrder" class="btn btn-primary ">Submit</button>
                                        </div>
                                    </section> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--        item Ordering-->
            <div class="col-md-3">
                <div class="text-danger"><?= @$messages['error_Product_Exists']; ?></div>
                <form id='product' action="reqForm.php" method="POST" >
                    <div class="card text-dark bg-light  mb-3 m-1" style="width: 18rem;">
                        <?php
                        $db = dbconn();
                        $sqlCategory = "SELECT CatergoryID,CatergoryName FROM catergories WHERE CatergoryStatus='1'";
                        $resultCategory = $db->query($sqlCategory);
                        ?>
                        <div class="card-body text-center">
                            <h5 class="card-title">Add Products</h5>
                            <div class="mb-3">
                                <label for="CategoryName" class="form-label">Product Name</label>
                                <select id='CategoryName' for="CategoryName" name="CategoryName" class="form-select" aria-label="Default select example" onchange='loadProducts()'>
                                    <option>--</option>
                                    <?php
                                    if ($resultCategory->num_rows > 0) {
                                        while ($rowCategory = $resultCategory->fetch_assoc()) {
                                            ?>
                                            <option value="<?= $rowCategory['CatergoryID'] ?>" <?php
                                            if (@$CategoryName == $rowCategory['CatergoryName']) {
                                                echo "selected";
                                            }
                                            ?>><?= $rowCategory['CatergoryName'] ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                </select>
                                <div class="text-danger"><?= @$messages['error_Product_Name']; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="ProductName" class="form-label">Product Name</label>
                                <select id='ProductName' for="ProductName" name="ProductName" class="form-select" aria-label="Default select example">
                                    <option value=''>--</option>

                                </select>
                                <div class="text-danger"><?= @$messages['error_Product_Name']; ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="QtyProduct" class="form-label">Qty</label>
                                <input type="text" class="form-control" id="QtyProduct" name="QtyProduct"
                                       placeholder="Enter Qty">
                                <div class="text-danger"><?= @$messages['error_Product_Qty']; ?></div>
                            </div>
                            <input type="hidden" name="JobCardsInspetionId" value="<?= $JobCardsInspetionId ?>" >
                            <input type="hidden" name="jobCardsRepairId" value="<?= $jobCardsRepairId; ?>" >
                            <button type="submit" name="action" value="addProduct" class="btn btn-dark ">Add Product</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php include'../../footer.php'; ?>
<script>
    function loadProducts() {
////        alert("loadCustomerName");
//        var formData = $('#addSkills').serialize();
        var selectedOption = $('#CategoryName').val();
        console.log(selectedOption);
        $.ajax({
            type: 'POST',
            url: 'loadProducts.php',
            data: {options: selectedOption},
            success: function (response) {
                $('#ProductName').html(response);
//                alert(response);
                //$('#citylist').modal('show');
                //alert(response)
            },
            error: function () {
                alert('Error submitting the form!');
            }
        });
    }
</script>