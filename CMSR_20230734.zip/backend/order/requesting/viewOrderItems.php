<?php include'../../header.php'; ?>
<?php include'../../menu.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Orders</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="viewReqItems.php" class="btn btn-sm btn-outline-secondary">View Orders</a>
            </div>
        </div>
    </div>
    <h2>Order List</h2>
    <div class="container">
        <div class="row">
            <?php
            extract($_POST);

            if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == 'edit') {
                $JobCardsInspetionId;
                $jobCardsRepairId;
                $db = dbconn();
                $sql = "SELECT ins.InspectionId,ins.InspectionNo,ins.AddDate,ins.Millege,ins.inspectionNotes,"
                        . "cv.vehicleId,cv.registerLetter,cv.RegistrationNo,vc.CatergoryName,u.FirstName,u.LastName,cus.CustomerID,cus.FirstName AS 'CustomerFirstName',cus.LastName AS 'CustomerLastName' FROM inspections ins "
                        . "LEFT JOIN customervehicles cv ON ins.VehicleNo=cv.vehicleId "
                        . "LEFT JOIN vehicle_catergories vc ON cv.VehicleType=vc.VCatergoryId "
                        . "LEFT JOIN users u ON ins.AddUser=u.UserId "
                        . "LEFT JOIN customer cus ON ins.CustomerName=cus.CustomerID WHERE InspectionId='$JobCardsInspetionId';";
                $result = $db->query($sql);
                $row = $result->fetch_assoc();
                $JobCardsInspetionId = $row['InspectionId'];
                $row['CustomerFirstName'];
                $row['CustomerLastName'];
                $row['CatergoryName'];
                $row['Millege'];
                $row['AddDate'];
                $row['InspectionNo'];
                $row['FirstName'];
                $row['LastName'];
                $customerId = $row['CustomerID'];
                $VehicleId = $row['vehicleId'];

                $sql1 = "SELECT jobCardsRepairId,JobCardNo FROM Job_cardsrepair WHERE jobCardsRepairId = '$jobCardsRepairId'";
                $result1 = $db->query($sql1);
                $row1 = $result1->fetch_assoc();
                $jobCardsRepairId = $row1['jobCardsRepairId'];
                $row1['JobCardNo'];
                $jobCardNo = $row1['jobCardsRepairId'];

                $sql2 = "SELECT orderNo,Status FROM orders WHERE JobCardNo = '$jobCardNo'";
                $result2 = $db->query($sql2);
                $row2 = $result2->fetch_assoc();
                $OrderNo = $row2['orderNo'];
                $Status = $row2['Status'];
            }
            ?>





            <div class="col-md-12">
                <div class="card">
                    <div class="col-md-12">
                        <div class="card">
                            <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
                                <div class="card-body">
                                    <section class="m-1">
                                        <div class="card-header">
                                            <img width="60" src="<?= SYSTEM_PATH ?>/assets/img/logo.png" title="logo" alt="logo" 
                                                 style="
                                                 width:60px;
                                                 display: block;
                                                 margin: 0 auto;
                                                 ">
                                            <h5 class='m-1'style="text-align: center; font-weight: bold;">Replica Speed Motor Garage</h5>
                                            <p class='m-1' style="text-align: center;">130A, Horahena Rd, Pannipitiya.</p>
                                            <p class='m-1' style="text-align: center;">0779 200 480</p>
                                        </div>
                                        <div class="card-body">
                                            <h5 class='m-1'style="text-align: center; font-weight: bold;">Order Summary</h5>
                                            <div class="row">
                                                <div class="col">
                                                    <div>
                                                        <p> Customer Name : <?= $row['CustomerFirstName'] . ' ' . $row['CustomerLastName']; ?>
                                                        </p>
                                                    </div>
                                                    <div>
                                                        <p>Vehicle No : <?= $row['registerLetter'] . ' - ' . $row['RegistrationNo']; ?> </p>
                                                    </div>
                                                    <div>
                                                        <p>Vehicle Type : <?= $row['CatergoryName']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Millage : <?= $row['Millege']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Order No : <?= $OrderNo ?></p>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div>
                                                        <p> INS Date :  <?= $row['AddDate']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p> INS NO. :<?= $row['InspectionNo']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Inspection Officer :  <?= $row['FirstName'] . ' ' . $row['LastName']; ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Job Card No:  <?= $row1['JobCardNo'] ?></p>
                                                    </div>
                                                    <div>
                                                        <p>Order Status : <?php
                                                            $Status;
                                                            $statusDescription = '';

                                                            switch ($Status) {
                                                                case 1:
                                                                    $statusDescription = "Order Request Sent";
                                                                    $statusColor = "btn btn-warning btn-sm";
                                                                    break;
                                                                case 2:
                                                                    $statusDescription = "Items Recieved";
                                                                    $statusColor = "btn btn-success btn-sm";
                                                                    break;
                                                                default:
                                                                    $statusDescription = "Not Available";
                                                                    $statusColor = "btn btn-secondary btn-sm";
                                                                    break;
                                                            }
                                                            ?>
                                                            <span class='<?= $statusColor; ?>'><?= $statusDescription; ?> </span>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                    <section>
                                        <div class="container m-1">
                                            <section>
                                                <h6>Products</h6>
                                                <table class="table m-1">
                                                    <thead>
                                                        <tr style="background-color: #d2d2d2">
                                                            <th scope="col">#</th>
                                                            <th scope="col">Description</th>
                                                            <th scope="col">Qty</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                         echo $sqlshowproduct = "SELECT od.id,od.orderNo,p.ProductName,odr.Qty FROM orders od "
                                                        . "LEFT JOIN orderitems odr ON odr.OrderId=od.id"
                                                        . " LEFT JOIN products p ON odr.ProductId=p.ProductId "
                                                        . "WHERE JobCardNo = '$jobCardsRepairId';";
                                                        $db = dbConn();
                                                        $resultshowproduct = $db->query($sqlshowproduct);
                                                        ?>



                                                        <?php
                                                        $totalProduct = 0;
                                                        if ($resultshowproduct->num_rows > 0) {
                                                            $i = 1;

                                                            while ($rowshowp = $resultshowproduct->fetch_assoc()) {
                                                                ?><tr>
                                                                    <td><?= $i ?></td>
                                                                    <td><?= $rowshowp['ProductName'] ?></td>
                                                                    <td><?= $rowshowp['Qty'] ?></td>
                                                                </tr>
                                                                <?php
                                                                $i++;
                                                            }
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </section>
                                        </div>
                                        <div class="card-footer">
                                            <a href="viewReqItems.php" class="btn btn-sm btn-danger">Close</a>
                                        </div>
                                    </section> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include'../../footer.php'; ?>
