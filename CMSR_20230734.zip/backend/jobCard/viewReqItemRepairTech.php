<?php include'../header.php'; ?>
<?php include'../menu.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Job Cards</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="addJobCard.php" class="btn btn-sm btn-outline-secondary">Add Job Card</a>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar" class="align-text-bottom"></span>
                This week
            </button>
        </div>
    </div>
    <h2>Job Card List</h2>
    <div class="table-responsive">
        <?php
        $userId = $_SESSION['userId'];
        $db = dbconn();
        $sql = "SELECT jb.jobCardsRepairId, jb.JobCardNo,jb.Status, ins.InspectionNo,ins.InspectionId,ins.AddDate, c.FirstName, c.LastName, cv.VehicleModel, cv.VehicleType, cv.registerLetter, cv.RegistrationNo, "
                . "vc.CatergoryName FROM job_cardsrepair jb "
                . "LEFT JOIN users u ON jb.empId = u.UserId "
                . "LEFT JOIN inspections ins ON ins.InspectionId = jb.InspectionId LEFT JOIN customer c ON ins.CustomerName = c.CustomerID "
                . "LEFT JOIN customervehicles cv ON ins.VehicleNo = cv.vehicleId "
                . "LEFT JOIN vehicle_catergories vc ON cv.VehicleType = vc.VCatergoryId "
                . "WHERE jb.Status = 1 AND jb.empId = '$userId' ORDER BY jb.AddDate AND jb.AddTime DESC;";
        $result = $db->query($sql); // Run Query
//        print_r($result);
        ?>
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Job Card No</th>
                    <th scope="col">Inspection No</th>
                    <th scope="col">Inspection Date</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Vehicle No</th>
                    <th scope="col">Vehicle Type</th>
                    <th scope="col">Vehicle Model</th>
                    <th scope="col">Job Status</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $n = 1;
                    while ($row = $result->fetch_assoc()) {
//                        print_r($row)
                        ?>
                        <tr>
                            <td><?= $n ?></td>
                            <td><?= $row['JobCardNo'] ?></td>
                            <td><?= $row['InspectionNo'] ?></td>
                            <td><?= $row['AddDate'] ?></td>
                            <td>
                                <?= $row['FirstName'] . ' ' . $row['LastName'] ?></td>
                            <td>
                                <?= $row['registerLetter'] . "-" . $row['RegistrationNo']; ?>
                            </td>
                            <td><?= $row['CatergoryName'] ?></td>
                            <td><?= $row['VehicleModel'] ?></td>
                            <td><?php
                                $JobCardStatus = $row['Status'];
                                $statusDescription = '';

                                switch ($JobCardStatus) {
                                    case 1:
                                        $statusDescription = "Repair in Progress";
                                        $statusColor = "btn btn-warning btn-sm";
                                        break;
                                    case 2:
                                        $statusDescription = "Requested Items";
                                        $statusColor = "btn btn-success btn-sm";
                                        break;
                                    case 4:
                                        $statusDescription = "Requested Items";
                                        $statusColor = "btn btn-success btn-sm";
                                        break;
                                    case 4:
                                        $statusDescription = "Received Items";
                                        $statusColor = "btn btn-success btn-sm";
                                        break;
                                    case 5:
                                        $statusDescription = "Finished";
                                        $statusColor = "btn btn-success btn-sm";
                                        break;
                                    default:
                                        $statusDescription = "Not Available";
                                        $statusColor = "btn btn-secondary btn-sm";
                                        break;
                                }
                                ?>
                                <!--                                   //$row['appointmentStatus'] == 1 ? "Pending" : 'Not Availble'-->
                                <span class='<?= $statusColor; ?>'><?= $statusDescription; ?> </span>



                            </td>
                            <td>
                                <form method='post' action="../order/requesting/reqForm.php">
                                    <input type="hidden" name="jobCardsRepairId" value="<?= $row['jobCardsRepairId'] ?>">
                                    <input type="hidden" name="JobCardsInspetionId" value="<?= $row['InspectionId'] ?>">
                                    <button type="submit" name="action" value="edit" class="btn btn-sm btn-primary">Request Items</button>
                                </form>

                            </td>
                            <td>
                                <form method='post' action="../order/reqesting/reqForm.php">
                                    <input type="hidden" name="jobCardsRepairId" value="<?= $row['jobCardsRepairId'] ?>">
                                    <input type="hidden" name="JobCardsInspetionId" value="<?= $row['InspectionId'] ?>">
                                    <button type="submit" name="action" value="edit" class="btn btn-sm btn-primary">View Job Card</button>
                                </form>

                            </td>
                        </tr>
                        <?php
                        $n++;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php include'../footer.php'; ?>