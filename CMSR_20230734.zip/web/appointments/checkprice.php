<?php
include '../config.php';
include '../function.php';
extract($_POST);

$db = dbConn();

if($ServiceType != 0){

    


$sql = "Select * from servicetypes where Service_Id='$ServiceType'";
$result = $db->query($sql);

$db = dbConn();
$sqlSType = "Select ServiceName from service where ServiceId='$ServiceType'";
$resultSname = $db->query($sqlSType);
$row3 = $resultSname->fetch_assoc();
?>
<link href="../assets/css/style.css">


<div class="mb-3" style="background-color: white;">

    <h5 style="text-align: center;"><strong>Estimated Service Amount <br>
            <?= $row3['ServiceName'] ?></strong></h5>

    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Product Name</th>
                <th scope="col">Qty</th>
                <th scope="col">Rate</th>
                <th scope="col">Amount</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $n = 1;
                $total = 0;
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <td><?= $n ?></td>
                        <td>
                            <?php
                            $Product = $row['Product_Id'];
                            $sqlProduct = "SELECT ProductName FROM products WHERE ProductId='$Product'";
                            $resultVehicle = $db->query($sqlProduct);
                            $rowProduct = $resultVehicle->fetch_assoc();
                            ?>
                            <?= $rowProduct['ProductName'] ?></td>
                        <td>
                            <?php
                            $Product = $row['Product_Id'];
                            $sqlProductQty = "SELECT Qty FROM servicetypes WHERE Product_Id='$Product' AND Service_Id='$ServiceType'";
                            $resultQty = $db->query($sqlProductQty);
                            $rowQty = $resultQty->fetch_assoc();
                            ?>
                            <?php echo @$qty = $rowQty['Qty'] ?>
                        </td>
                        <td>
                            <?php
                            $Product = $row['Product_Id'];
                            $sqlProductPrice = "SELECT * FROM products INNER JOIN stock ON products.ProductId = stock.Product_Id WHERE products.ProductId=$Product ORDER BY stock.Date ASC LIMIT 1;";
                            $resultPrice = $db->query($sqlProductPrice);
                            $rowProductPrice = $resultPrice->fetch_assoc();
                            ?>
                            <?php echo @$price = $rowProductPrice['SalePrice'] ?>
                        </td>
                        <td>


                            <?php echo $sum = @$qty * @$price ?>
                        </td>

                        <td>

                        </td>
                    </tr>
                    <?php
                    $n++;
                    $total += $sum;
                }
            }
//        echo $summ += $sum;
            ?>
        </tbody>
        <tfoot>
            <tr>
                <td><strong>Sum</strong></td>
                <td></td>
                <td></td>
                <td></td>
                <td><strong><?= $total ?></strong></td>
            </tr>
            <tr>
                <td colspan="5"> <p style="color: red; text-align: center;">**Prices and availability are subject to change without notice</p>
                    &nbsp;</td>
            </tr>
        </tfoot>
        <!--        <div class="footer">
                    <p>Prices and availability are subject to change without notice</p>
                </div>-->
    </table>

</div>


<?php } ?>
