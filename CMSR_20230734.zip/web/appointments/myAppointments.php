<?php include'../header.php'; ?>
<?php
extract($_POST);
$customerId = $_SESSION['CustomerID'];
$sql = "SELECT * FROM appointments WHERE CustomerID='$customerId'";
$db = dbconn();
$result = $db->query($sql);
?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="background-color: white;"">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">My Appointments </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <button type="button" class="btn btn-primary btn-sm" onclick="history.back()">Go Back</button>
            </div>
        </div>
    </div>
    <div>
    </div>
    <div class="table-responsive" style="background-color: white;">
        <table class="table table-striped table-bordered table-sm table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Appointment No.</th>
                    <th scope="col">Appointment Date</th>
                    <th scope="col">Vehicle Number</th>
                    <th scope="col">Service Type</th>
                    <th scope="col">Appointment Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $n = 1;
                    while ($row = $result->fetch_assoc()) {
//                        
                        ?>
                        <tr>
                            <td>
                                <?= $n ?>
                            </td>
                            <td>
                                <?= $row['AppointmentNo'] ?> 
                            </td>
                            <td>
                                <?= $row['AppDate'] ?> 
                            </td>
                            <td>
                                <?php
                                $vehicle = $row['VehicleNo'];
                                $sqlVehicle = "SELECT * FROM customervehicles WHERE vehicleId='$vehicle'";
                                $resultVehicle = $db->query($sqlVehicle);
                                $rowVehicle = $resultVehicle->fetch_assoc();
                                ?>
                                <?= $rowVehicle['registerLetter'] . "-" . $rowVehicle['RegistrationNo']; ?>
                            </td>
                            <td>
                                <?= $row['ServiceType'] ?> 
                            </td>
                            <td>
                                <?php
                                $appointmentStatus = $row['appointmentStatus'];
                                $statusDescription = '';

                                switch ($appointmentStatus) {
                                    case 1:
                                        $statusDescription = "Pending";
                                        $statusColor = "btn btn-warning btn-sm";
                                        break;
                                    case 2:
                                        $statusDescription = "In Porgress";
                                        $statusColor = "btn btn-success btn-sm";
                                        break;
                                    case 3:
                                        $statusDescription = "Complete";
                                        $statusColor = "btn btn-primary btn-sm";
                                        break;
                                    case 4:
                                        $statusDescription = "Canceled";
                                        $statusColor = "btn btn-danger btn-sm";
                                        break;
                                    default:
                                        $statusDescription = "Not Available";
                                        $statusColor = "btn btn-secondary btn-sm";
                                        break;
                                }
                                ?>
                                <!--                                   //$row['appointmentStatus'] == 1 ? "Pending" : 'Not Availble'-->
                                <span class='<?= $statusColor; ?>'><?= $statusDescription; ?> </span>
                            </td>
                            <td>

                                <?php
                                //timestart=Time Slot starting Time
                                $bookedDate = $row['AppDate'];
                                $DateBooked = strtotime($bookedDate);
                                $currentdate = date('Y-m-d');
                                $DateCurrent = strtotime($currentdate);
                                $prev_date = date('Y-m-d', strtotime($bookedDate . ' -2 day'));
                                $DateCanceled = strtotime($prev_date);
                                $prev_date1 = date('Y-m-d', strtotime($currentdate . ' -1 day'));
                                $DateCanceled1 = strtotime($prev_date1);
                                $timegap = $DateBooked - $DateCurrent;
                                $StaticDate = ($DateCurrent - $DateCanceled1) * 2;
                                echo $appointmentStatus;
                                if ($appointmentStatus == 4) {
                                    $disabled = "disabled";
                                } else {
                                    $disabled = "";
                                }
                                ?>
                                <?php if ($timegap <= $StaticDate) { ?> 
                                    <form method='post' action="appViewBill.php" class="btn-group">
                                        <input type="hidden" name="appointmentId" value="<?= $row['AppointmentId'] ?>">
                                        <button type="submit" class="btn btn-primary" name="action" value="viewBill" <?= @$disabled ?>>View Bill</button>
                                    </form>
                                    <form method='post' action="appComplaints.php" class="btn-group">
                                        <input type="hidden" name="appointmentId" value="<?= $row['AppointmentId'] ?>">
                                        <button type="submit" class="btn btn-warning" name="action" value="addComplaint" <?= @$disabled ?>>Add Complaint</button>
                                    </form>
                                    <button type="button" class="btn btn-danger" disabled>Cancel</button>
                                <?php } else { ?>
                                    <form method='post' action="appViewBill.php" class="btn-group">
                                        <input type="hidden" name="appointmentId" value="<?= $row['AppointmentId'] ?>">
                                        <button type="submit" class="btn btn-primary" name="action" value="viewBill" <?= @$disabled ?>>View Bill</button>
                                    </form>
                                    <form method='post' action="appComplaints.php" class="btn-group">
                                        <input type="hidden" name="appointmentId" value="<?= $row['AppointmentId'] ?>">
                                        <button type="submit" class="btn btn-warning" name="action" value="addComplaint" <?= @$disabled ?>>Add Complaint</button>
                                    </form>
                                    <form method='post' action="appCancel.php" class="btn-group">
                                        <input type="hidden" name="appointmentId" value="<?= $row['AppointmentId'] ?>">
                                        <button type="submit" class="btn btn-danger" name="action" value="cancel" <?= @$disabled ?>>Cancel</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                            $n++;
                        }
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php include'../footer.php'; ?>