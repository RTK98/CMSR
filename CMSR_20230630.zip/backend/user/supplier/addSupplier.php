<?php include'../../header.php'; ?>
<?php include'../../menu.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Add Supplier</h1>
    </div>
    <div class="card">
        <div class="card-header">
            New Supplier
        </div>
        <?php
        echo @$_POST["SupplierName"];
       print_r($_POST);
        ?>
        <form method="post" action="<?=
        $_SERVER['PHP_SELF'];
        ?>">
            <div class="card-body">
                <div class="mb-3">
                    <label for="SupplierID" class="form-label">Supplier ID</label>
                    <input type="text" class="form-control" id="SupplierID" name="SupplierID"
                        placeholder="Enter Supplier ID">
                </div>
                <div class="mb-3">
                    <label for="SupplierName" class="form-label">Supplier Name</label>
                    <input type="text" class="form-control" id="SupplierName" name="SupplierName"
                        placeholder="Enter Supplier Name">
                </div>
                <div class="mb-3">
                    <label for="RegDate" class="form-label">Registerd Date</label>
                    <input type="date" class="form-control" id="RegDate" name="RegDate"
                        placeholder="Enter Regsiterd Date">
                </div>
                <div class="mb-3">
                    <label for="Catergories" class="form-label">Catergories</label>
                    <select class="form-select form-control" id="Catergories" name="Catergories" aria-label="Default select example">
                        <option selected>Open this select menu</option>
                        <option value="1">One</option>
                        <option value="2">Two</option>
                        <option value="3">Three</option>
                    </select>
                    <!-- <input type="select" class="form-control" id="Catergories" name="Catergories"
                        placeholder="Select Catergories"> -->
                </div>
                <div class="mb-3">
                    <label for="SupplierContactNo" class="form-label">Contact No</label>
                    <input type="text" class="form-control" id="SupplierContactNo" name="SupplierContactNo"
                        placeholder="Enter Supplier Contact Number">
                </div>
                <div class="mb-3">
                    <label for="SupplierEmail" class="form-label">Email</label>
                    <input type="text" class="form-control" id="SupplierEmail" name="SupplierEmail"
                        placeholder="Enter Supplier Email">
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
    </div>
    </div>
    <div class="card-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    </form>
    </div>
    </div>
</main>
<?php include'../../footer.php'; ?>