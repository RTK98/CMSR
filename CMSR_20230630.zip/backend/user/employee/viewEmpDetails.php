<?php ob_start(); ?>
<?php include'../../header.php'; ?>
<?php include'../../menu.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">My Profile</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="viewEmp.php" class="btn btn-sm btn btn-dark position-relative">Emplyoee List</a>
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar" class="align-text-bottom"></span>
                This week
            </button>
        </div>
    </div>
    <?php
    extract($_POST);
    if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == "edit") {
        $db = dbConn();
        $sql = "SELECT UserId,FirstName,Lastname,Email,HouseNo,Lane,Street,City,Gender,NIC,Status,UserRole FROM users WHERE UserId='$UserId'";
        $result = $db->query($sql);
        $row = $result->fetch_assoc();
        print_r($row);
//        die();
        $FirstName = $row["FirstName"];
        $LastName = $row["Lastname"];
        $NIC = $row["NIC"];
        $HouseNo = $row["HouseNo"];
        $Lane1 = $row["Lane"];
        $Lane2 = $row["Street"];
        $City = $row["City"];
        $Email = $row["Email"];
        $UserRole = $row["UserRole"];
    }
    if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == "update") {
        $messages = array();

        if (!isset($UserRole)) {
            $messages['error_Designation'] = "Please Select the Employee Desgination..!";
        }
        if (empty($messages)) {
            $db = dbconn();
            $AddDate = date('Y-m-d');
            echo $sql = "UPDATE users SET UserRole='$UserRole',UpdateUser='1',`UpdateDate`='$AddDate' WHERE UserId='$UserId'";
            $db->query($sql);
        }
    }
    if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action == "cancel") {
        header("Location:viewEmp.php");
    }
    ?>
    <div>
        <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>">
            <div class="main-body">
                <div class="row gutters-sm">
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-column align-items-center text-center">
                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Admin" class="rounded-circle" width="150">
                                    <div class="mt-3">
                                        <h4>  <?php echo $_SESSION["FirstName"] . " " . $_SESSION["LastName"] ?></h4>
                                        <p class="text-secondary mb-1">Customer</p>
                                        <p class="text-muted font-size-sm">
                                            136, Horahena Road Rukmale Pannipitiya</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card mb-3">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Full Name</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" id="FirstName" name="FirstName"
                                               value="<?= $FirstName . ' ' . $LastName ?>" disabled>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">NIC</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" id="NIC" name="NIC"
                                               value="<?= $NIC ?>" disabled>
                                    </div>
                                </div>
                                <hr>

                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Email</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" id="Email" name="Email"
                                               value="<?= $Email ?>" disabled>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <?php
                                    $db = dbconn();
                                    $sql = "SELECT MobileNo FROM customer_mobile WHERE customerID='$UserId'";
                                    $result = $db->query($sql); // Run Query
                                    $row = $result->fetch_assoc();
                                    $MobileNo = $row['MobileNo'];
                                    ?>
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Phone</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" id="MobileNo" name="MobileNo"
                                               value="<?= '0' . $MobileNo ?>" disabled>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">
                                            Address</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <input type="text" class="form-control" id="FirstName" name="FirstName"
                                               value="<?= $HouseNo . ' ' . $Lane1 . ' ' . $Lane2 . ' ' . $City ?>" disabled>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">
                                            Dessgination</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <?php
                                        $db = dbconn();
                                        $sqlUserRole = "SELECT UserRole FROM desgination WHERE UserRole != 'admin'";
                                        $resultUserRole = $db->query($sqlUserRole);
                                        ?>
                                        <div class="mb-3">
                                            <select for="UserRole" name="UserRole"class="form-select" aria-label="Default select example">
                                                <option value="NoUserRole">--</option>
                                                <?php
                                                if ($resultUserRole->num_rows > 0) {

                                                    while ($row = $resultUserRole->fetch_assoc()) {
                                                        ?>
                                                        <option value="<?= $row['UserRole'] ?>" <?php
                                                        if ($UserRole == $row['UserRole']) {
                                                            echo "selected";
                                                        }
                                                        ?>><?= $row['UserRole'] ?>
                                                        </option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="text-danger"><?= @$messages['error_Designation']; ?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <input type="hidden" name="UserId" value="<?= $UserId ?>">
                                        <button type="submit" class="btn btn-primary" name="action" value="update">Submit</button>
                                        <input type="hidden" name="UserId" value="<?= $UserId ?>">
                                        <button type="submit" class="btn btn-danger" name="action" value="cancel">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</main>
<?php include'../../footer.php'; ?>
<?php ob_end_flush(); ?>