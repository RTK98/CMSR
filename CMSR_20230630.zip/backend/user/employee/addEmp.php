<?php include'../../header.php'; ?>
<?php include'../../menu.php'; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Employee</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="viewEmp.php" class="btn btn-sm btn-outline-secondary">View Employee</a>
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar" class="align-text-bottom"></span>
                This week
            </button>
        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h3>Add Employee</h3>
        </div>
        <?php
        print_r($_POST);
        if ($_SERVER['REQUEST_METHOD'] === "POST") {
            extract($_POST);
            $FirstName = inputTrim($FirstName);
            $LastName = inputTrim($LastName);
            $NIC = inputTrim($NIC);
            $HouseNo = inputTrim($HouseNo);
            $Lane1 = inputTrim($Lane1);
            $Lane2 = inputTrim($Lane2);
            $City = inputTrim($City);
            $Email = inputTrim($Email);
            $Password = sha1($Password);
            $messages = array();
            if (empty($FirstName)) {
                $messages['error_First_Name'] = "The First Name should not be blank..!";
            }
            if (empty($LastName)) {
                $messages['error_Last_Name'] = "The Last Name should not be blank..!";
            }
            if (empty($NIC)) {
                $messages['error_NIC'] = "The NIC should not be blank..!";
            }
            if (empty($HouseNo)) {
                $messages['error_House_No'] = "The House No should not be blank..!";
            }
            if (empty($Lane1)) {
                $messages['error_Lane_1'] = "The Lane 1 should not be blank..!";
            }
            if (empty($Lane2)) {
                $messages['error_Lane_2'] = "The Lane 2 should not be blank..!";
            }
            if (empty($City)) {
                $messages['error_City'] = "The City should not be blank..!";
            }
            if (empty($Email)) {
                $messages['error_Email'] = "The Email should not be blank..!";
            }
            if (empty($Password)) {
                $messages['error_Password'] = "The Password should not be blank..!";
            }
            if (!isset($Gender)) {
                $messages['error_Gender'] = "The Gender should not be blank..!";
            }
            if (!isset($Title)) {
                $messages['error_Title'] = "Please Select the Title..!";
            }
            if (!isset($UserRole)) {
                $messages['error_Designation'] = "Please Select the Desgination..!";
            }
            // if(!isset($Size)){
            //     $messages['error_Product_size'] = "The Product Size should not be blank..!";
            // }

            if ($_FILES['UserImage']['name'] != "") {
                $customerImage = $_FILES['UserImage'];
                $filename = $customerImage['name'];
                $filetmpname = $customerImage['tmp_name'];
                $filesize = $customerImage['size'];
                $fileerror = $customerImage['error'];
                //take file extension
                $file_ext = explode(".", $filename);
                $file_ext = strtolower(end($file_ext));
                //select allowed file type
                $allowed = array("jpg", "jpeg", "png", "gif");
                //check wether the file type is allowed
                if (in_array($file_ext, $allowed)) {
                    if ($fileerror === 0) {
                        //file size gives in bytes
                        if ($filesize <= 40000000) {
                            //giving appropriate file name. Can be duplicate have to validate using function
                            $file_name_new = $NIC . uniqid('', true) . '.' . $file_ext;
                            //directing file destination
                            $file_path = "../../assets/img/UserImages/" . $file_name_new;
                            //moving binary data into given destination
                            if (move_uploaded_file($filetmpname, $file_path)) {
                                "The file is uploaded successfully";
                            } else {
                                $messages['file_error'] = "File is not uploaded";
                            }
                        } else {
                            $messages['file_error'] = "File size is invalid";
                        }
                    } else {
                        $messages['file_error'] = "File has an error";
                    }
                } else {
                    $messages['file_error'] = "Invalid File type";
                }
            }
            //advance validation
            if (!empty($Email)) {
                $db = dbconn();
                $sql = "SELECT * FROM users WHERE Email='$Email'";
                $result = $db->query($sql);

                if ($result->num_rows > 0) {
                    $messages['error_Email'] = "The Email Already Exists!";
                }
            }
            if (empty($messages)) {
                $db = dbconn();
                $AddDate = date('Y-m-d');
                echo $sql = "INSERT INTO users (Title,UserImage,UserRole,Email,Password,NIC,FirstName,LastName,HouseNo,Lane,Street,City,Gender,Status)VALUES ('$Title','$file_name_new','$UserRole','$Email', '$Password', '$NIC', '$FirstName', '$LastName','$HouseNo','$Lane1','$Lane2','$City','$Gender','1')";
                $db->query($sql);
//            header('Location:addSuccess.php');
            }
        }
        ?>
        <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
            <div class="card-body">
                <?php
                $db = dbconn();
                $sql = "SELECT titleId,Name FROM title";
                $result = $db->query($sql);
                ?>
                <div class="mb-3">
                    <lable for="Title" class="form-label">Title</lable>
                    <select for="Title" name="Title" class="form-select" aria-label="Default select example">
                        <option value="NoTitle">--</option>
                        <?php
                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <option value="<?= $row['Name'] ?>" <?php
                                if (@$Title == $row['Name']) {
                                    echo "selected";
                                }
                                ?>><?= $row['Name'] ?></option>
                                        <?php
                                    }
                                }
                                ?>
                    </select>
                    <div class="text-danger"><?= @$messages['error_Title']; ?></div>
                </div>
                <?php
                $db = dbconn();
                $sql = "SELECT UserRole FROM desgination";
                $result = $db->query($sql);
                ?>
                <div class="mb-3">
                    <lable for="UserRole" class="form-label">Designation</lable>
                    <select for="UserRole" name="UserRole"class="form-select" aria-label="Default select example">
                        <option value="NoUserRole">--</option>
                        <?php
                        if ($result->num_rows > 0) {

                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <option value="<?= $row['UserRole'] ?>" <?php
                                if (@$Title == $row['UserRole']) {
                                    echo "selected";
                                }
                                ?>><?= $row['UserRole'] ?></option>
                                        <?php
                                    }
                                }
                                ?>
                    </select>
                    <div class="text-danger"><?= @$messages['error_Designation']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="UserImage" class="form-label">Upload Image</label>
                    <input type="file" class="form-control" id="UserImage" name="UserImage">
<!--                    <div class="text-danger"><?= @$messages['error_Vehicle_image']; ?></div>-->
                </div>
                <div class="mb-3">
                    <label for="FirstName" class="form-label">First Name</label>
                    <input type="text" class="form-control" id="FirstName" name="FirstName"
                           placeholder="Enter First Name">
                    <div class="text-danger"><?= @$messages['error_First_Name']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="LastName" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="LastName" name="LastName"
                           placeholder="Enter Last Name">
                    <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="TimeSlotEnd" class="form-label">NIC</label>
                    <input type="text" class="form-control" id="NIC" name="NIC"
                           placeholder="Enter NIC">
                    <div class="text-danger"><?= @$messages['error_NIC']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="HouseNo" class="form-label">House No</label>
                    <input type="text" class="form-control" id="HouseNo" name="HouseNo"
                           placeholder="Enter Last Name">
                    <div class="text-danger"><?= @$messages['error_House_No']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="Lane1" class="form-label">Lane 1</label>
                    <input type="text" class="form-control" id="Lane1" name="Lane1"
                           placeholder="Enter Address Lane 1">
                    <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="Lane2" class="form-label">Lane 2</label>
                    <input type="text" class="form-control" id="Lane2" name="Lane2"
                           placeholder="Enter Address Lane 2">
                    <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="City" class="form-label">City</label>
                    <input type="text" class="form-control" id="City" name="City"
                           placeholder="Enter Address Lane 2">
                    <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
                </div>

                <div class="mb-3">
                    <label for="Gender" class="form-label">Gender</label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="Gender" id="Male" value="1">
                        <label class="form-check-label" for="Yes">Yes</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="Gender" id="Female" value="2">
                        <label class="form-check-label" for="Female">Female</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="Gender" id="Other" value="3">
                        <label class="form-check-label" for="Other">Other</label>
                    </div>
                    <div class="text-danger"><?= @$messages['error_Gender']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="Email" class="form-label">Email</label>
                    <input type="text" class="form-control" pattern="[^ @]*@[^ @]*" id="Email" name="Email"
                           placeholder="Email">
                    <div class="text-danger"><?= @$messages['error_email']; ?></div>
                </div>
                <div class="mb-3">
                    <label for="Password" class="form-label">Password</label>
                    <input type="password" pattern=".{8,}" class="form-control" id="Password" name="Password"
                           placeholder="Enter Password">
                    <div class="text-danger"><?= @$messages['error_Email']; ?></div>
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
    </div>
</main>
<?php include'../../footer.php'; ?>