<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?= $_SESSION["FirstName"] ?>'s Dashboard </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar" class="align-text-bottom"></span>
                This week
            </button>
        </div>
    </div>
    <h2>Section title</h2>
    <section>  
        <div class="row">
            <div class="col-sm-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body text-center">
                        <h5 class="card-titletext-center ">Today Appointments</h5>
                        <h5 class="card-text text-center"></h5>
                        <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../products/products.php'"> View All Products</a></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-center">Tomorrow Appointments</h5>

                        <h5 class="card-text text-center"></h5>
                        <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../products/activeproducts.php'"> View Active Products</a></div>

                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-center">Daily Collection</h5>

                        <h5 class="card-text text-center"></h5>
                        <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../products/inactiveproducts.php'"> View  In-Active Products</a></div>
                    </div>
                </div>
            </div>
    </section>
    <section>
        <div class="row">
            <div class="col-sm-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-center">Pending Jobs </h5>

                        <h5 class="card-text text-center"></h5>
                        <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../category/categories.php'"> View All Categories</a></div>

                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-center">Completed Jobs </h5>

                        <h5 class="card-text text-center"></h5>
                        <div class="text-center text-decoration-none"><a class="text-decoration-none"  href="dirname(__FILE__) .'/../../category/activecategories.php'"> View Active Categories</a></div>

                    </div>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="card" style="width: 18rem;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-center">Attendance</h5>

                        <h5 class="card-text text-center"></h5>
                        <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../category/inactivecategories.php'"> View In-Active Categories</a></div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <section>  
            <div class="row">
                <div class="col-sm-3">
                    <div class="card" style="width: 18rem;">
                        <div class="card-body text-center">
                            <h5 class="card-titletext-center ">Re-Order Stocks</h5>
                            <h5 class="card-text text-center"></h5>
                            <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../sucessstories/allsuccesstories.php'"> View All SucessStories</a></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card" style="width: 18rem;">
                        <div class="card-body text-center">
                            <h5 class="card-titletext-center ">Most Popular Products</h5>
                            <h5 class="card-text text-center"></h5>
                            <div class="text-center text-decoration-none"><a class="text-decoration-none" href="dirname(__FILE__) .'/../../sucessstories/activesucessstories.php'"> View Active SucessStories</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</main>

