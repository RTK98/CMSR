<?php include'../header.php' ; ?>
<?php include'../menu.php' ; ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Time Slots</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="addTimeSlot.php" class="btn btn-sm btn-outline-secondary">Add New Time Slot</a>
            </div>
            <div class="btn-group me-2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>
        </div>
    </div>
    <h2>Time Slot</h2>
    <div class="table-responsive">
    <?php
         $db=dbconn();
         $sql="SELECT * FROM timeslots";
        $result=$db->query($sql); // Run Query
        ?>
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Time Slot Name</th>
                    <th scope="col">Starting Time</th>
                    <th scope="col">End Time</th>
                    <th scope="col">Per Vehicles</th>
                    <th scope="col">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
              if($result->num_rows>0){
                $n=1;
                while($row=$result->fetch_assoc()){
                ?>
                <tr>
                    <td><?= $n ?></td>
                    <td><?=$row['TimeSlotName']?></td>
                    <td><?=$row['TimeSlotStart']?></td>
                    <td><?=$row['TimeSlotEnd']?></td>
                    <td><?=$row['PerVehicles']?></td>
                    <td><?=$row['TimeSlotStatus']?></td>
                    <td>
                        <form method='post' action="editTimeSlot.php">
                            <input type="text" name="TimeSlotId" value="<?=$row['TimeSlotId']?>">
                            <button type="submit" name="action" value="edit">Edit</button>
                        </form>

                    </td>
                </tr>
                <?php
                $n++;
              }
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php include'../footer.php' ; ?>