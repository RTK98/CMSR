<?php ob_start();?>
<?php include'../header.php' ; ?>
<?php include'../menu.php' ; ?>
<style>
<?php include '../assets/css/styles.css';
?>
</style>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manage Inspections</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">
                <a href="addInspection.php" class="btn btn-sm btn-outline-secondary">Add Inspection</a>
                <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar" class="align-text-bottom"></span>
                This week
            </button>
        </div>
    </div>
    <h2>View Inspection</h2>

    <div class="card text-center">
        <?php
    extract($_POST);
    if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action=="view") {
          $db=dbConn();
          $sql="SELECT * FROM inspections WHERE InspectionId='$InspectionId'";
          print_r($sql);
          $result=$db->query($sql);
          $rowz = $result->fetch_assoc();
          $CustomerName=$rowz["CustomerName"];
          
        }
        if ($_SERVER['REQUEST_METHOD'] === "POST" && @$action=="submit") {
            $db=dbConn();
            $sql2="SELECT * FROM inspections INNER JOIN inspectionsreport ON inspections.InspectionId = inspectionsreport.InspectionId 
            JOIN repaircatergory ON inspectionsreport.InspectionStatus = repaircatergory.RepairId WHERE inspections.InspectionId= $InspectionId ";
             $result=$db->query($sql2);
             $row=$result->fetch_assoc();
             $InspectionNo=$row["InspectionNo"];
             $VehicleNo=$row["VehicleNo"];
             $CustomerName=$row["CustomerName"];
             $Millege=$row["Millege"];
            echo $InspectionNo;
            echo $VehicleNo;
            echo $CustomerName;
            echo $Millege;
            $AddDate=date('Y-m-d');
            $sql="INSERT INTO selected_inspections (InspectionNo,VehicleNo,CustomerName,Millege,AddUser,AddDate) VALUES ('$InspectionNo','$VehicleNo','$CustomerName','$Millege','1','$AddDate')";
            $result=$db->query($sql);
            $InspectionId=$db->insert_id;
            foreach($InspectionStatus as $value){
               $sql="INSERT INTO selected_inspectionreports(InspectionId,InspectionStatus) VALUES ('$InspectionId','$value')";
                print_r($sql);
                $db->query($sql);
            }
            header('Location:addSuccess.php');
        }

      
        ?>
        <div class="card-header">
            <h4>Replica Speed Motor Garage</h4>
            <h5>Adress</h>
        </div>
        <div class="card-body">
            <?php
             $db=dbConn();
             $sql="SELECT * FROM inspections INNER JOIN inspectionsreport ON inspections.InspectionId = inspectionsreport.InspectionId 
            JOIN repaircatergory ON inspectionsreport.InspectionStatus = repaircatergory.RepairId WHERE inspections.InspectionId= $InspectionId ";
             $result=$db->query($sql);
            if($result->num_rows>0){
            $row=$result->fetch_assoc();
            ?>
            <div class="row">
                <div class="col">
                    <div>
                        <p> Customer name :<?=$row['CustomerName']?>
                        </p>
                    </div>
                    <div>
                        <p>Vehicle No : <?=$row['VehicleNo']?></p>
                    </div>
                    <div>
                        <p>Inspection Officer :</p>
                    </div>
                </div>
                <div class="col">
                    <div>
                        <p> INS Date : <?=$row['AddDate']?></p>
                    </div>
                    <div>
                        <p> INS NO. : <?=$row['InspectionNo']?></p>
                    </div>
                </div>
            </div>
            <?php
            }
            
            ?>
        </div>
        <div class="card-footer text-muted">
            2 days ago
        </div>
    </div>
    <div class="table-responsive">
        <?php
         $db=dbconn();
         $sql="SELECT * FROM inspections JOIN inspectionsreport ON inspections.InspectionId = inspectionsreport.InspectionId 
         JOIN repaircatergory ON inspectionsreport.InspectionStatus = repaircatergory.RepairId  WHERE inspections.InspectionId= $InspectionId ";
        $result=$db->query($sql); // Run Query
        ?>
        <form method="post" action="<?=$_SERVER['PHP_SELF'];?>">
            <table class="table table-striped table-sm">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Repair Name</th>
                        <th scope="col">warranty</th>
                        <th scope="col">Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
              if($result->num_rows>0){
                $n=1;
                $price=0;
                while($row=$result->fetch_assoc()){
                ?>
                    <tr>
                        <td><?= $n ?></td>
                        <td><?=$row['RepairName']?></td>
                        <td><?=$row['WarrantyType']?></td>
                        <td><?=$row['RepairPrice']?></td>

                        <?php $price += $row['RepairPrice']?>
                        <?php $_SESSION['inspecid']= $row['InspectionId']; ?>
                        <!-- <td><?=  $price ?></td> -->
                        <td><input type="checkbox" value="<?= $row['RepairId']?>" name="InspectionStatus[]"
                                <?php if(isset($InspectionStatus) && in_array(@$RepairId, @$InspectionStatus)) {echo 'checked'; }?> />
                            &nbsp;
                        </td>
                    </tr>
                    <?php
                $n++;
              }
                }
                ?>
                    <tfooter>
                        <p> <?= $price ?> </p>
                    </tfooter>
                </tbody>
            </table>
            <div class="card-footer">
                <input type="text" name="InspectionId" value="<?= $_SESSION['inspecid'] ?> ">
                <button type="submit" name="action" value="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
</main>
<?php include'../footer.php' ; ?>
<?php ob_end_flush();?>