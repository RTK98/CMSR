<script src="<?= SYSTEM_PATH ?>assets/js/jquery.min.js"></script>
<script src="<?= SYSTEM_PATH ?>assets/js/jquery-1.12.4.js"></script>
<script src="<?= SYSTEM_PATH ?>assets/js/bootstrap.bundle.min.js"></script>
<script>
    let subMenu = document.getElementById("subMenu");

    function toggleMenu() {
        subMenu.classList.toggle("open-menu");
    }
</script>
</body>

</html>
<?php ob_flush(); ?>
