<?php
//Create constatnt variabble to store system url
define("SYSTEM_PATH","http://localhost/CMSR/web/");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");
define("DBNAME", "cmsr");

?>