<?php include '../header.php'; ?>;
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <?php
    print_r($_POST);
    if ($_SERVER['REQUEST_METHOD'] === "POST") {
        extract($_POST);
        $FirstName = inputTrim($FirstName);
        $LastName = inputTrim($LastName);
        $NIC = inputTrim($NIC);
        $HouseNo = inputTrim($HouseNo);
        $Lane1 = inputTrim($Lane1);
        $Lane2 = inputTrim($Lane2);
        $City = inputTrim($City);
        $Email = inputTrim($Email);
        $Password = sha1($Password);
        $messages = array();
        if (empty($FirstName)) {
            $messages['error_First_Name'] = "The First Name should not be blank..!";
        }
        if (empty($LastName)) {
            $messages['error_Last_Name'] = "The Last Name should not be blank..!";
        }
        if (empty($NIC)) {
            $messages['error_NIC'] = "The NIC should not be blank..!";
        }
        if (empty($HouseNo)) {
            $messages['error_House_No'] = "The House No should not be blank..!";
        }
        if (empty($Lane1)) {
            $messages['error_Lane_1'] = "The Lane 1 should not be blank..!";
        }
        if (empty($Lane2)) {
            $messages['error_Lane_2'] = "The Lane 2 should not be blank..!";
        }
        if (empty($City)) {
            $messages['error_City'] = "The City should not be blank..!";
        }
        if (empty($Email)) {
            $messages['error_Email'] = "The Email should not be blank..!";
        }
        if (empty($Password)) {
            $messages['error_Password'] = "The Password should not be blank..!";
        }
        if (!isset($Gender)) {
            $messages['error_Gender'] = "The Gender should not be blank..!";
        }
        // if(!isset($Size)){
        //     $messages['error_Product_size'] = "The Product Size should not be blank..!";
        // }
        //advance validation
        if (!empty($Email)) {
            $db = dbconn();
            $sql = "SELECT * FROM products WHERE ProductName='$Email'";
            $result = $db->query($sql);

            if ($result->num_rows > 0) {
                $messages['error_Product_size'] = "The Product Name Already Exists!";
            }
        }
        if (empty($messages)) {
            $db = dbconn();
            $AddDate = date('Y-m-d');
            echo $sql = "INSERT INTO customer (Email,Password,NIC,FirstName,LastName,HouseNo,Lane1,Lane2,City,Gender,Status)VALUES ('$Email', '$Password', '$NIC', '$FirstName', '$LastName','$HouseNo','$Lane1','$Lane2','$City','$Gender','1')";
            $db->query($sql);
//            header('Location:addSuccess.php');
        }
    }
    ?>
    <form method="post" action="<?= $_SERVER['PHP_SELF']; ?>" style="background: white;">
        <div class="card-body">
            <div class="mb-3">
                <label for="FirstName" class="form-label">First Name</label>
                <input type="text" class="form-control" id="FirstName" name="FirstName"
                       placeholder="Enter First Name">
                <div class="text-danger"><?= @$messages['error_First_Name']; ?></div>
            </div>
            <div class="mb-3">
                <label for="LastName" class="form-label">Last Name</label>
                <input type="text" class="form-control" id="LastName" name="LastName"
                       placeholder="Enter Last Name">
                <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
            </div>
            <div class="mb-3">
                <label for="TimeSlotEnd" class="form-label">NIC</label>
                <input type="text" class="form-control" id="NIC" name="NIC"
                       placeholder="Enter NIC">
                <div class="text-danger"><?= @$messages['error_NIC']; ?></div>
            </div>
            <div class="mb-3">
                <label for="HouseNo" class="form-label">House No</label>
                <input type="text" class="form-control" id="HouseNo" name="HouseNo"
                       placeholder="Enter Last Name">
                <div class="text-danger"><?= @$messages['error_House_No']; ?></div>
            </div>
            <div class="mb-3">
                <label for="Lane1" class="form-label">Lane 1</label>
                <input type="text" class="form-control" id="Lane1" name="Lane1"
                       placeholder="Enter Address Lane 1">
                <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
            </div>
            <div class="mb-3">
                <label for="Lane2" class="form-label">Lane 2</label>
                <input type="text" class="form-control" id="Lane2" name="Lane2"
                       placeholder="Enter Address Lane 2">
                <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
            </div>
            <div class="mb-3">
                <label for="City" class="form-label">City</label>
                <input type="text" class="form-control" id="City" name="City"
                       placeholder="Enter Address Lane 2">
                <div class="text-danger"><?= @$messages['error_Last_Name']; ?></div>
            </div>

            <div class="mb-3">
                <label for="Gender" class="form-label">Gender</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="Gender" id="Male" value="1">
                    <label class="form-check-label" for="Yes">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="ProductStatus" id="Female" value="2">
                    <label class="form-check-label" for="Female">Female</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="ProductStatus" id="Other" value="3">
                    <label class="form-check-label" for="Other">Other</label>
                </div>
                <div class="text-danger"><?= @$messages['error_Gender']; ?></div>
            </div>
            <div class="mb-3">
                <label for="Email" class="form-label">Email</label>
                <input type="text" class="form-control" pattern="[^ @]*@[^ @]*" id="Email" name="Email"
                       placeholder="Email">
                <div class="text-danger"><?= @$messages['error_email']; ?></div>
            </div>
            <div class="mb-3">
                <label for="Password" class="form-label">Password</label>
                <input type="password" pattern=".{8,}" class="form-control" id="Password" name="Password"
                       placeholder="Enter Password">
                <div class="text-danger"><?= @$messages['error_Email']; ?></div>
            </div>

            <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
    </form>
</main>