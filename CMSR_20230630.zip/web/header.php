<?php
session_start();
include 'config.php';
include 'function.php';
?>
<!doctype html>
<html>

    <head>
        <meta name='viewport' content="width=device-width, initial-scale=1.8">
        <title>Replica Speed</title>
<!--        <link rel="stylesheet" href="<?= SYSTEM_PATH ?>assets/css/style.css">-->
        <link rel="stylesheet" href="<?= SYSTEM_PATH ?>assets/css/style.css">
        <link href="<?= SYSTEM_PATH ?>assets/css/bootstrap.min.css" rel="stylesheet">
<!--        <script src="<?= SYSTEM_PATH ?>assets/js/sweetalert2.all.js"></script>-->
    </head>

    <body>
        <div class="header">
            <nav>
                <div class="logo">
                    <img src="<?= SYSTEM_PATH ?>assets/img/logo.png" alt="logo">
                    <span>Replica Speed</span>
                </div>
                <ul>
                    <li><a href="<?= SYSTEM_PATH ?>" class=" active">Home</a></li>
                    <li><a href="about.php" class=" active">About</a></li>
                    <li><a href="#">Services</a></li>
                    <li><a href="<?= SYSTEM_PATH ?>appointments/addAppointment.php">Schedule</a></li>
                    <li><a href="#">Gallery</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Contact</a></li>


                    <li>
                        <?php if (!isset($_SESSION['CustomerID'])) { ?>

                            <a href="<?= SYSTEM_PATH ?>customer/login.php"">Login</a></li> <?php }
                        ?>

                    <!--                    <li>-->
                    <?php // if (isset($_SESSION['CustomerID'])) { ?>

                    <!--                            <a href="customer/logout.php">Log out</a></li>-->
                    <?php // }
                    ?>

                    <li>
                        <?php if (isset($_SESSION['CustomerID'])) { ?>
                            <div class="navbar-nav">
                                <nav>
                                    <img src="<?= SYSTEM_PATH ?>assets/img/user.png" class="user-pic" onclick="toggleMenu()">
                                    <div class="sub-menu-wrap" id="subMenu">
                                        <div class="sub-menu">
                                            <div class="user-info">
                                                <img src="<?= SYSTEM_PATH ?>assets/img/user.png" alt="Bootstrappin'">
                                                <h3><?= $_SESSION["FirstName"] ?><?= $_SESSION["LastName"] ?></h3>
                                            </div>
                                            <hr>
                                            <a href="<?= SYSTEM_PATH ?>customer/viewUser.php"" class="sub-menu-link">
                                                <img src="<?= SYSTEM_PATH ?>assets/img/profile.png">
                                                <p>My Profile</p>
                                                <span>></span>
                                            </a>
                                            <a href="#" class="sub-menu-link">
                                                <img src="<?= SYSTEM_PATH ?>assets/img/setting.png">
                                                <p>Setting & Privacy</p>
                                                <span>></span>
                                            </a>
                                            <a href="#" class="sub-menu-link">
                                                <img src="<?= SYSTEM_PATH ?>assets/img/help.png">
                                                <p>Help & Support</p>
                                                <span>></span>
                                            </a>
                                            <a href="<?= SYSTEM_PATH ?>customer/logout.php" class="sub-menu-link">
                                                <img src="<?= SYSTEM_PATH ?>assets/img/logout.png">
                                                <p>Log out</p>
                                                <span>></span>
                                            </a>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </li> <?php }
                        ?>
                </ul>
            </nav>